class Object:
    _intProp = 0
    _charProp = 'a'
