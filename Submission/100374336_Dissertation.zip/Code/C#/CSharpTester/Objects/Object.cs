﻿namespace CSharpTester.Objects
{
    public class Object
    {
        public int IntProperty { get; set; } = 0;
        public char CharProperty { get; set; } = 'a';
    }
}