package tester.java.Objects;

public class Object {
    private int intProperty = 0;
    private char charProperty = 'a';
}